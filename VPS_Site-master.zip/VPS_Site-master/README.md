<h1 align="center">VPS Site</h1>


<p align="center">VPS Site Is Made By _Dreyannz_ Forked From The PHP Code Made By <a href=https://www.phcorner.net/members/1189527/>Phcmjal</a></p>
<p align="center">I Have 2 Versions Of The New PHP Code.</p>
<p align="center"> The 1st Is A Simplier One That Only Requires User Input Of Username And Password.</p>
<p align="center">The 2nd Is Much More Complicated In Which Separates VIP Users From Free Users.</p>

<h3 align="center">Installation</h3>
  <p align="center">wget https://raw.githubusercontent.com/Dreyannz/VPS_Site/master/vps_site.sh</p>
  <p align="center">chmod +x vps_site.sh</p>
  <p align="center">./vps_site.sh</p>
  

<h3 align="center">Youtube Video</h3>
<p align="center">
https://youtu.be/NBFft7OgJEU
</p>

<h3 align="center">Screenshots</h3>
<p align="center">
<img src="https://raw.githubusercontent.com/Dreyannz/VPS_Site/master/Screenshots/1.JPG">
   </p>
   <p align="center">
<img src="https://raw.githubusercontent.com/Dreyannz/VPS_Site/master/Screenshots/2.JPG">
   </p>



