<?php $_F=__FILE__;$_X='Pz48P3BocA0KNG5jbDNkNSAndmFfczVydjVyX2Q1dDE0bHMucGhwJzsNCi8qIEQybnQgRWQ0dCBBbnkgUDFydCBPZiBUaDUgQzJkNSBJZiBZMjMgRDJudCBLbjJ3IEgydyBJdCBXMnJrcyovDQokNXJyMnIgPSBmMWxzNTsNCjRmICg0c3M1dCgkX1BPU1RbJzNzNXInXSkpIA0KCXsNCgkJJDNzNXJuMW01ID0gdHI0bSgkX1BPU1RbJzNzNXInXSk7DQoJCSQzczVybjFtNSA9IHN0cjRwX3QxZ3MoJDNzNXJuMW01KTsNCgkJJDNzNXJuMW01ID0gaHRtbHNwNWM0MWxjaDFycygkM3M1cm4xbTUpOw0KCQkkcDFzc3cycmQ2ID0gdHI0bSgkX1BPU1RbJ3Axc3N3MnJkJ10pOw0KCQkkcDFzc3cycmQ2ID0gc3RyNHBfdDFncygkcDFzc3cycmQ2KTsNCgkJJHAxc3N3MnJkNiA9IGh0bWxzcDVjNDFsY2gxcnMoJHAxc3N3MnJkNik7DQoJCSQ0bnY0dDVfYzJkNSA9ICRfUE9TVFsnNG52NHQ1J107DQoJCSQ0bnY0dDVfYzJkNSA9IHN0cjRwX3QxZ3MoJDRudjR0NV9jMmQ1KTsNCgkJJDRudjR0NV9jMmQ1ID0gaHRtbHNwNWM0MWxjaDFycygkNG52NHQ1X2MyZDUpOw0KCQkNCgkJDQoJCQ0KCQk0ZiAoNW1wdHkoJDNzNXJuMW01KSkgDQoJCQl7DQoJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkkbjFtNUVycjJyID0gIlBsNTFzNSBJbnAzdCBBIFVzNXJuMW01LiI7DQoJCQl9DQoJCTVsczUgNGYgKHN0cmw1bigkM3M1cm4xbTUpIDwgbykgDQoJCQl7DQoJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkkbjFtNUVycjJyID0gIlVzNXJuMW01IE0zc3QgSDF2NSBBdGw1MXQgbyBDaDFyMWN0NXJzLiI7DQoJCQl9DQoJCTRmICg1bXB0eSgkcDFzc3cycmQ2KSkNCgkJCXsNCgkJCQkkNXJyMnIgPSB0cjM1Ow0KCQkJCSRwMXNzRXJyMnIgPSAiUGw1MXM1IElucDN0IEEgUDFzc3cycmQuIjsNCgkJCX0gDQoJCTVsczUgNGYoc3RybDVuKCRwMXNzdzJyZDYpIDwgbykgDQoJCQl7DQoJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkkcDFzc0VycjJyID0gIlAxc3N3MnJkIE0zc3QgSDF2NSBBdGw1MXN0IG8gQ2gxcjFjdDVycy4iOw0KCQkJfQ0KCQlmMnIgKCRyMncgPSA2OyAkcjJ3IDwgNjA2OyAkcjJ3KyspDQoJCQl7DQoJCQk0ZiAoICRfUE9TVFsnczVydjVyJ10gPT0gJHM1cnY1cl9sNHN0c18xcnIxeVskcjJ3XVs2XSApDQoJCQkJew0KCQkJCTRmICggJHM1cnY1cl9sNHN0c18xcnIxeVskcjJ3XVt1XSA9PSAiVklQIiApDQoJCQkJCXsNCgkJCQkJCTRmICggITVtcHR5KCQ0bnY0dDVfYzJkNSkpDQoJCQkJCQkJew0KCQkJCQkJCQk0ZiAoICQ0bnY0dDVfYzJkNSAhPSAkNG52NHQ1X2MyZDVfbTFzdDVyICkNCgkJCQkJCQkJCXsNCgkJCQkJCQkJCQkkNXJyMnIgPSB0cjM1Ow0KCQkJCQkJCQkJCSQ0bnY0dDVFcnIyciA9ICJJbnY0dDUgQzJkNSBJcyBJbmMycnI1Y3QiOw0KCQkJCQkJCQkJfQ0KCQkJCQkJCQk1bHM1DQoJCQkJCQkJCQl7DQoJCQkJCQkJCQkJJGgyc3RzPSAkczVydjVyX2w0c3RzXzFycjF5WyRyMnddW2FdOw0KCQkJCQkJCQkJCSRyMjJ0X3Axc3M9ICRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bb107DQoJCQkJCQkJCQkJDQoJCQkJCQkJCQkJYnI1MWs7DQoJCQkJCQkJCQl9DQoJCQkJCQkJfQ0KCQkJCQkJNWxzNQ0KCQkJCQkJCXsNCgkJCQkJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkJCQkJJDRudjR0NUVycjJyID0gIlBsNTFzNSBJbnAzdCBJbnY0dDUgQzJkNSI7DQoJCQkJCQkJfQkJCQkNCgkJCQkJfQ0KCQkJCTVsczU0ZiAoICRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bdV0gPT0gIkZyNTUiICkNCgkJCQkJew0KCQkJCQkJJGgyc3RzPSAkczVydjVyX2w0c3RzXzFycjF5WyRyMnddW2FdOw0KCQkJCQkJJHIyMnRfcDFzcz0gJHM1cnY1cl9sNHN0c18xcnIxeVskcjJ3XVtvXTsNCgkJCQkJCQ0KCQkJCQkJYnI1MWs7DQoJCQkJCX0NCgkJCQl9DQoJCQl9DQoJCTRmICggJF9QT1NUWyczczVyX3R5cDUnXSA9PSAiVklQIFVzNXIiKQ0KCQkJew0KCQkJCTRmICggNW1wdHkoJDRudjR0NV9jMmQ1KSkNCgkJCQkJew0KCQkJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkJCSQ0bnY0dDVFcnIyciA9ICJQbDUxczUgSW5wM3QgSW52NHQ1IEMyZDUiOw0KCQkJCQl9DQoJCQkJNWxzNQ0KCQkJCQl7DQoJCQkJCQkkNXhwNHIxdDQybj0gJHY0cF8zczVyXzV4cDsNCgkJCQkJfQ0KCQkJCQ0KCQkJfQ0KCQk1bHM1NGYgKCAkX1BPU1RbJzNzNXJfdHlwNSddID09ICJGcjU1IFVzNXIiKQ0KCQkJew0KCQkJCTRmICggNW1wdHkoJDRudjR0NV9jMmQ1KSkNCgkJCQl7DQoJCQkJCSQ1eHA0cjF0NDJuPSAkZnI1NV8zczVyXzV4cDsNCgkJCQl9DQoJCQkJNWxzNQ0KCQkJCXsNCgkJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkJJDRudjR0NUVycjJyID0gIkludjR0NSBDMmQ1IElzIEYyciBWSVAgVXM1cnMgT25seSI7DQoJCQkJfQ0KCQkJfQ0KDQoJCSRwMXNzdzJyZDYgPSAkX1BPU1RbJ3Axc3N3MnJkJ107DQoJCSRuRDF5cyA9ICQ1eHA0cjF0NDJuOw0KCQkkZDF0NXNzID0gZDF0NSgnbS9kL3knLCBzdHJ0MnQ0bTUoJysnLiRuRDF5cy4nIGQxeXMnKSk7DQoJCSRwMXNzdzJyZCA9IDVzYzFwNXNoNWxsMXJnKCBjcnlwdCgkcDFzc3cycmQ2KSApOw0KCQk0ZiggISQ1cnIyciApIA0KCQkJew0KCQkJCWQxdDVfZDVmMTNsdF90NG01ejJuNV9zNXQoJ1VUQycpOw0KCQkJCWQxdDVfZDVmMTNsdF90NG01ejJuNV9zNXQoIkFzNDEvTTFuNGwxIik7IA0KCQkJCSRteV9kMXQ1ID0gZDF0NSgiWS1tLWQgSDo0OnMiKTsgDQoJCQkJJGMybm41Y3Q0Mm4gPSBzc2hhX2Mybm41Y3QoJGgyc3RzLCBhYSk7DQoJCQkJNGYgKHNzaGFfMTN0aF9wMXNzdzJyZCgkYzJubjVjdDQybiwgJ3IyMnQnLCAkcjIydF9wMXNzKSkgDQoJCQkJCXsNCgkJCQkJCSRzaDJ3ID0gdHIzNTsJIA0KCQkJCQkJc3NoYV81eDVjKCRjMm5uNWN0NDJuLCAiM3M1cjFkZCAkM3M1cm4xbTUgLW0gLXAgJHAxc3N3MnJkIC01ICRkMXQ1c3MgLWQgIC90bXAvJDNzNXJuMW01IC1zIC9iNG4vZjFsczUiKTsNCgkJCQkJCSRzM2NjID0gJ0FkZDVkIFMzY2M1c2YzbGx5JzsNCgkJCQkJCTRmICgkcjVzKSANCgkJCQkJCQl7DQoJCQkJCQkJCSQ1cnJUeXAgPSAiczNjYzVzcyI7DQoJCQkJCQkJCSQ1cnJNU0cgPSAiUzNjYzVzc2YzbGx5IHI1ZzRzdDVyNWQsIHkyMyBtMXkgQ2g1Y2sgeTIzciBjcjVkNW50NDFscyI7DQoJCQkJCQkJCSQzczVybjFtNSA9ICcnOw0KCQkJCQkJCQkkcDFzc3cycmQgPSAnJzsNCgkJCQkJCQl9IA0KCQkJCQkJNWxzNSANCgkJCQkJCQl7DQoJCQkJCQkJCSQ1cnJUeXAgPSAiZDFuZzVyIjsNCgkJCQkJCQkJJDVyck1TRyA9ICJTMm01dGg0bmcgdzVudCB3cjJuZywgdHJ5IDFnMTRuIGwxdDVyLi4uIjsgDQoJCQkJCQkJfSANCgkJCQkJfSANCgkJCQk1bHM1IA0KCQkJCQl7DQoJCQkJCQlkNDUoJ0Mybm41Y3Q0Mm4gRjE0bDVkLi4uJyk7DQoJCQkJCX0JDQoJCQl9ICAgDQoJfSANCj8+';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />  
<title><?php echo $site_name;?>   |   <?php echo $site_description;?>   |   </title>
    	<script language='JavaScript'>
        var txt = '   ' + document.title + '   '
        var speed = 400;
        var refresh = null;
        function site_name() 
		{
            		document.title = txt;
            		txt = txt.substring(1, txt.length) + txt.charAt(0);
            		refresh = setTimeout("site_name()", speed);
        	}
        site_name();     
    </script>
<link rel="shortcut icon" type="image/x-icon" href="/logo.png" height="200" width"200">
<meta name="description" content="<?php echo $site_description;?>"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.1.1/<?php echo $site_template;?>/bootstrap.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
</head>
<body>
	<div class="navbar navbar-expand-lg navbar-dark bg-danger">
		<div class="container">
			<a class="navbar-brand" href="/"><?php echo $site_name;?></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigatebar" aria-controls="navigatebar" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navigatebar">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item">
						<a class="nav-link" href="https://www.phcorner.net/members/745093/">PHCorner</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<header id="header" align="center">
		<img src="/logo.png" alt="" height="250" width"250"/>
	</header>
	<div align="center">
        	<div class="col-md-4" align="center">
				<div align="center">
    					<div align="center" class="card-body">
							<form method="post" align="center" class="softether-create">
								<div class="form-group">
									<div class="alert-danger">
										<span class="text-light"><?php echo $nameError; ?></span>
									</div>					
									<div class="alert-danger">
										<span class="text-light"><?php echo $passError; ?></span>
									</div>
									<div class="alert-danger">
										<span class="text-light"><?php echo $inviteError; ?></span>
									</div>
								</div>
								<div class="form-group">	
										<?php
											if($show == true) 
												{
													echo '<div class="card alert-danger">';
													echo '<table class="table-danger">';
													echo '<tr>'; echo '<td> </td>'; echo '<td> </td>'; echo '</tr>';			
													echo '<tr>'; echo '<td>Host</td>'; echo '<td>'; echo $hosts; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>Username</td>'; echo '<td>'; echo $username; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>Password</td>'; echo '<td>'; echo $password1; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>Server</td>'; echo '<td>'; echo $_POST['server']; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>User Type</td>'; echo '<td>'; echo $_POST['user_type']; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>SSH Port</td>'; echo '<td>'; echo $port_ssh; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>Dropbear Port</td>'; echo '<td>'; echo $port_dropbear; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>SSL Port</td>'; echo '<td>'; echo $port_ssl; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>Squid Port</td>'; echo '<td>'; echo $port_squid; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>OpenVPN Config</td>'; echo '<td>';echo '<a href="http://';echo $hosts; echo "/"; echo "client.ovpn"; echo'">download config</a>'; echo '</td>'; echo '</tr>';
													echo '<tr>'; echo '<td>Expiration Date</td>'; echo '<td>'; echo $datess; echo '</td>'; echo '</tr>';																							
													echo '<tr>'; echo '<td> </td>'; echo '<td> </td>'; echo '</tr>';
													echo '</table>';
													echo '</div>';
												}										
										?>
								</div>
								<div class="form-group">
									<div class="input-group">									
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="fas fa-globe" style="color:red;"></i></span>
										</div>
										<select class="custom-select" name="server" required>
											<option disabled selected value>Select Server</option> 
												<optgroup label="VIP Servers">
													<?php $_F=__FILE__;$_X='Pz48P3BocA0KCQkJCQkJCQkJCQkJCQlmMnIgKCRyMncgPSA2OyAkcjJ3IDwgNjA2OyAkcjJ3KyspDQoJCQkJCQkJCQkJCQkJCXsNCgkJCQkJCQkJCQkJCQkJCTRmICgoICRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bdV0gPT0gVklQICkpDQoJCQkJCQkJCQkJCQkJCQl7DQoJCQkJCQkJCQkJCQkJCQkJNWNoMiAnPDJwdDQybj4nOzVjaDIgJHM1cnY1cl9sNHN0c18xcnIxeVskcjJ3XVs2XTsgNWNoMiAnPC8ycHQ0Mm4+JzsNCgkJCQkJCQkJCQkJCQkJCX0NCgkJCQkJCQkJCQkJCQkJCTVsczU0ZiAoICRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bdV0gPT0gRnI1NSApDQoJCQkJCQkJCQkJCQkJCQl7DQoJCQkJCQkJCQkJCQkJCQkJYzJudDRuMzU7DQoJCQkJCQkJCQkJCQkJCQl9DQoJCQkJCQkJCQkJCQkJCQk1bHM1DQoJCQkJCQkJCQkJCQkJCQl7DQoJCQkJCQkJCQkJCQkJCQkJYnI1MWs7DQoJCQkJCQkJCQkJCQkJCQl9DQoJCQkJCQkJCQkJCQkJCX0NCgkJCQkJCQkJCQkJCQk/Pg==';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>
												</optgroup>
												<optgroup label="Free Servers">
													<?php $_F=__FILE__;$_X='Pz48P3BocA0KCQkJCQkJCQkJCQkJCQlmMnIgKCRyMncgPSA2OyAkcjJ3IDwgNjA2OyAkcjJ3KyspDQoJCQkJCQkJCQkJCQkJCXsNCgkJCQkJCQkJCQkJCQkJCTRmICgoICRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bdV0gPT0gRnI1NSApKQ0KCQkJCQkJCQkJCQkJCQkJew0KCQkJCQkJCQkJCQkJCQkJCTVjaDIgJzwycHQ0Mm4+Jzs1Y2gyICRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bNl07IDVjaDIgJzwvMnB0NDJuPic7DQoJCQkJCQkJCQkJCQkJCQl9DQoJCQkJCQkJCQkJCQkJCQk1bHM1NGYgKCAkczVydjVyX2w0c3RzXzFycjF5WyRyMnddW3VdID09IFZJUCApDQoJCQkJCQkJCQkJCQkJCQl7DQoJCQkJCQkJCQkJCQkJCQkJYzJudDRuMzU7DQoJCQkJCQkJCQkJCQkJCQl9DQoJCQkJCQkJCQkJCQkJCQk1bHM1DQoJCQkJCQkJCQkJCQkJCQl7DQoJCQkJCQkJCQkJCQkJCQkJYnI1MWs7DQoJCQkJCQkJCQkJCQkJCQl9DQoJCQkJCQkJCQkJCQkJCX0NCgkJCQkJCQkJCQkJCQk/Pg==';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>	
												</optgroup>												
										</select> 
									</div>
								</div>
								<div class="form-group">
									<div class="input-group">									
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="fas fa-crown" style="color:red;"></i></span>
										</div>
										<select class="custom-select" name="user_type" required>
											<option disabled selected value>Type Of User</option> 
											<option>Free User</option>
											<option>VIP User</option>												
										</select> 
									</div>
								</div>
								<div class="form-group">								
									<div class="input-group">									
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="fas fa-user-circle" style="color:red;"></i></span>
										</div>
										<input type="text" class="form-control" id="username" placeholder="Username" name="user" autocomplete="off" >
									</div>							
								</div>					
								<div class="form-group">								
									<div class="input-group">
									<div class="input-group-prepend">
											<span class="input-group-text"><i class="fas fa-key" style="color:red;"></i></span>
										</div>
										<input type="text" class="form-control" id="password" placeholder="Password" name="password" autocomplete="off"  >
									</div>								
								</div>								
								<div class="form-group">									
									<div class="input-group">									
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="fas fa-code" style="color:red;"></i></span>
										</div>
										<input type="text" class="form-control" id="confirm" placeholder="Invite Code (VIP Users)" name="invite" autocomplete="off" >
									</div>
								</div>													
								<div class="form-group ">								
									<button type="submit" id="button" class="btn btn-danger btn-block btn-action">CREATE ACCOUNT</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
