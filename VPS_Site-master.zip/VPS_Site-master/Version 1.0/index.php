<?php $_F=__FILE__;$_X='Pz48P3BocA0KNG5jbDNkNSAndjZfczVydjVyX2Q1dDE0bHMucGhwJzsNCmYyciAoJHIydyA9IDY7ICRyMncgPCA2MDY7ICRyMncrKykNCgl7DQoJNGYgKCAkX1BPU1RbJ3M1cnY1ciddID09ICRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bNl0gKQ0KCQl7DQoJCSRoMnN0cz0gJHM1cnY1cl9sNHN0c18xcnIxeVskcjJ3XVthXTsNCgkJJHIyMnRfcDFzcz0gJHM1cnY1cl9sNHN0c18xcnIxeVskcjJ3XVtvXTsNCgkJJDV4cDRyMXQ0Mm49ICRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bdV07DQoJCWJyNTFrOw0KCQl9DQoJfQ0KJDVycjJyID0gZjFsczU7DQo0ZiAoNHNzNXQoJF9QT1NUWyczczVyJ10pKSANCgl7DQoJCSQzczVybjFtNSA9IHRyNG0oJF9QT1NUWyczczVyJ10pOw0KCQkkM3M1cm4xbTUgPSBzdHI0cF90MWdzKCQzczVybjFtNSk7DQoJCSQzczVybjFtNSA9IGh0bWxzcDVjNDFsY2gxcnMoJDNzNXJuMW01KTsNCgkJJHAxc3N3MnJkNiA9IHRyNG0oJF9QT1NUWydwMXNzdzJyZCddKTsNCgkJJHAxc3N3MnJkNiA9IHN0cjRwX3QxZ3MoJHAxc3N3MnJkNik7DQoJCSRwMXNzdzJyZDYgPSBodG1sc3A1YzQxbGNoMXJzKCRwMXNzdzJyZDYpOw0KCQkkY3Axc3N3MnJkID0gJF9QT1NUWydjMm5mNHJtcDFzc3cycmQnXTsNCgkJJGNwMXNzdzJyZCA9IHN0cjRwX3QxZ3MoJGNwMXNzdzJyZCk7DQoJCSRjcDFzc3cycmQgPSBodG1sc3A1YzQxbGNoMXJzKCRjcDFzc3cycmQpOw0KCQkkcDFzc3cycmQ2ID0gJF9QT1NUWydwMXNzdzJyZCddOw0KCQkkbkQxeXMgPSAkNXhwNHIxdDQybjsNCgkJJGQxdDVzcyA9IGQxdDUoJ20vZC95Jywgc3RydDJ0NG01KCcrJy4kbkQxeXMuJyBkMXlzJykpOw0KCQkkcDFzc3cycmQgPSA1c2MxcDVzaDVsbDFyZyggY3J5cHQoJHAxc3N3MnJkNikgKTsNCgkJDQoJCTRmICg1bXB0eSgkM3M1cm4xbTUpKSANCgkJCXsNCgkJCQkkNXJyMnIgPSB0cjM1Ow0KCQkJCSRuMW01RXJyMnIgPSAiUGw1MXM1IEVudDVyIEEgVXM1cm4xbTUuIjsNCgkJCX0NCgkJNWxzNSA0ZiAoc3RybDVuKCQzczVybjFtNSkgPCBvKSANCgkJCXsNCgkJCQkkNXJyMnIgPSB0cjM1Ow0KCQkJCSRuMW01RXJyMnIgPSAiVXM1cm4xbTUgTTNzdCBIMXY1IEF0bDUxc3QgbyBDaDFyMWN0NXJzLiI7DQoJCQl9DQoJCTRmICg1bXB0eSgkcDFzc3cycmQ2KSkNCgkJCXsNCgkJCQkkNXJyMnIgPSB0cjM1Ow0KCQkJCSRwMXNzRXJyMnIgPSAiUGw1MXM1IEVudDVyIEEgUDFzc3cycmQuIjsNCgkJCX0gDQoJCTVsczUgNGYoc3RybDVuKCRwMXNzdzJyZDYpIDwgbykgDQoJCQl7DQoJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkkcDFzc0VycjJyID0gIlAxc3N3MnJkIE0zc3QgSDF2NSBBdGw1MXN0IG8gQ2gxcjFjdDVycy4iOw0KCQkJfQ0KCQk0ZigkcDFzc3cycmQ2ICE9ICRjcDFzc3cycmQpDQoJCQl7DQoJCQkJJDVycjJyID0gdHIzNTsNCgkJCQkkY3AxczVyMnIgPSAiUDFzc3cycmQgRDRkbid0IE0xdGNoLiI7DQoJCQl9ICANCgkJNGYoICEkNXJyMnIgKSANCgkJCXsNCgkJCQlkMXQ1X2Q1ZjEzbHRfdDRtNXoybjVfczV0KCdVVEMnKTsNCgkJCQlkMXQ1X2Q1ZjEzbHRfdDRtNXoybjVfczV0KCJBczQxL00xbjRsMSIpOyANCgkJCQkkbXlfZDF0NSA9IGQxdDUoIlktbS1kIEg6NDpzIik7IA0KCQkJCSRjMm5uNWN0NDJuID0gc3NoYV9jMm5uNWN0KCRoMnN0cywgYWEpOw0KCQkJCTRmIChzc2hhXzEzdGhfcDFzc3cycmQoJGMybm41Y3Q0Mm4sICdyMjJ0JywgJHIyMnRfcDFzcykpIA0KCQkJCQl7DQoJCQkJCQkkc2gydyA9IHRyMzU7CSANCgkJCQkJCXNzaGFfNXg1YygkYzJubjVjdDQybiwgIjNzNXIxZGQgJDNzNXJuMW01IC1tIC1wICRwMXNzdzJyZCAtNSAkZDF0NXNzIC1kICAvdG1wLyQzczVybjFtNSAtcyAvYjRuL2YxbHM1Iik7DQoJCQkJCQkkczNjYyA9ICdBZGQ1ZCBTM2NjNXNmM2xseSc7DQoJCQkJCQk0ZiAoJHI1cykgDQoJCQkJCQkJew0KCQkJCQkJCQkkNXJyVHlwID0gInMzY2M1c3MiOw0KCQkJCQkJCQkkNXJyTVNHID0gIlMzY2M1c3NmM2xseSByNWc0c3Q1cjVkLCB5MjMgbTF5IENoNWNrIHkyM3IgY3I1ZDVudDQxbHMiOw0KCQkJCQkJCQkkM3M1cm4xbTUgPSAnJzsNCgkJCQkJCQkJJHAxc3N3MnJkID0gJyc7DQoJCQkJCQkJCSRjcDFzc3cycmQgPSAnJzsNCgkJCQkJCQl9IA0KCQkJCQkJNWxzNSANCgkJCQkJCQl7DQoJCQkJCQkJCSQ1cnJUeXAgPSAiZDFuZzVyIjsNCgkJCQkJCQkJJDVyck1TRyA9ICJTMm01dGg0bmcgdzVudCB3cjJuZywgdHJ5IDFnMTRuIGwxdDVyLi4uIjsgDQoJCQkJCQkJfSANCgkJCQkJfSANCgkJCQk1bHM1IA0KCQkJCQl7DQoJCQkJCQlkNDUoJ0Mybm41Y3Q0Mm4gRjE0bDVkLi4uJyk7DQoJCQkJCX0JDQoJCQl9ICAgDQoJfSANCj8+';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />  
<title><?php echo $site_name;?>   |   <?php echo $site_description;?>   |   </title>
    	<script language='JavaScript'>
        var txt = '   ' + document.title + '   '
        var speed = 400;
        var refresh = null;
        function site_name() 
		{
            		document.title = txt;
            		txt = txt.substring(1, txt.length) + txt.charAt(0);
            		refresh = setTimeout("site_name()", speed);
        	}
        site_name();     
    </script>
<link rel="shortcut icon" type="image/x-icon" href="/logo.png" height="200" width"200">
<meta name="description" content="<?php echo $site_description;?>"/>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.1.1/<?php echo $site_template;?>/bootstrap.min.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
</head>
<body>
	<div class="navbar navbar-expand-lg navbar-dark bg-danger">
		<div class="container">
			<a class="navbar-brand" href="/"><?php echo $site_name;?></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigatebar" aria-controls="navigatebar" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navigatebar">
				<ul class="navbar-nav mr-auto">
					<li class="nav-item">
						<a class="nav-link" href="https://www.phcorner.net/members/745093/">PHCorner</a>
					</li>
					
				</ul>
			</div>
		</div>
	</div>
	<header id="header" align="center">
		<img src="/logo.png" alt="" height="250" width"250"/>
	</header>
	<div align="center">
    	<div class="col-md-4" align="center">
			<div align="center">
				<div align="center" class="card-body">
					<form method="post" align="center" class="softether-create">
						<div class="form-group">
							<div class="alert-danger">
								<span class="text-light"><?php echo $nameError; ?></span>
							</div>					
							<div class="alert-danger">
								<span class="text-light"><?php echo $passError; ?></span>
							</div>
							<div class="alert-danger">
								<span class="text-light"><?php echo $cpaseror; ?></span>
							</div>
						</div>
						<div class="form-group">												
							<?php
								if($show == true) 
									{
										echo '<div class="card alert-danger">';
										echo '<table class="table-danger">';
										echo '<tr>'; echo '<td> </td>'; echo '<td> </td>'; echo '</tr>';			
										echo '<tr>'; echo '<td>Host</td>'; echo '<td>'; echo $hosts; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Username</td>'; echo '<td>'; echo $username; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Password</td>'; echo '<td>'; echo $password1; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>SSH Port</td>'; echo '<td>'; echo $port_ssh; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Dropbear Port</td>'; echo '<td>'; echo $port_dropbear; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>SSL Port</td>'; echo '<td>'; echo $port_ssl; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Squid Port</td>'; echo '<td>'; echo $port_squid; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>OpenVPN Config</td>'; echo '<td>';echo '<a href="http://';echo $hosts; echo "/"; echo "client.ovpn"; echo'">download config</a>'; echo '</td>'; echo '</tr>';
										echo '<tr>'; echo '<td>Expiration Date</td>'; echo '<td>'; echo $datess; echo '</td>'; echo '</tr>';																							
										echo '<tr>'; echo '<td> </td>'; echo '<td> </td>'; echo '</tr>';
										echo '</table>';
										echo '</div>';
									}										
							?>

						</div>
						<div class="form-group">
							<div class="input-group">									
								<div class="input-group-prepend">
									<span class="input-group-text"><i class="fas fa-globe" style="color:red;"></i></span>
								</div>
								<select class="custom-select" name="server" >
									<option disabled selected value>Select Server</option> 
										<optgroup label="LadyClare Servers">
											<?php $_F=__FILE__;$_X='Pz48P3BocA0KCQkJCQkJCQkJCQlmMnIgKCRyMncgPSA2OyAkcjJ3IDwgNjA2OyAkcjJ3KyspDQoJCQkJCQkJCQkJCXsNCgkJCQkJCQkJCQkJCTRmICggITVtcHR5KCRzNXJ2NXJfbDRzdHNfMXJyMXlbJHIyd11bNl0pKQ0KCQkJCQkJCQkJCQkJew0KCQkJCQkJCQkJCQkJCTVjaDIgJzwycHQ0Mm4+JzsgNWNoMiAkczVydjVyX2w0c3RzXzFycjF5WyRyMnddWzZdOyA1Y2gyICc8LzJwdDQybj4nOw0KCQkJCQkJCQkJCQkJfQ0KCQkJCQkJCQkJCQkJNWxzNQ0KCQkJCQkJCQkJCQkJew0KCQkJCQkJCQkJCQkJCWJyNTFrOw0KCQkJCQkJCQkJCQkJfQkJCQkJCQkJCQkJCQkJDQoJCQkJCQkJCQkJCX0NCgkJCQkJCQkJCQkJPz4=';eval(base64_decode('JF9YPWJhc2U2NF9kZWNvZGUoJF9YKTskX1g9c3RydHIoJF9YLCcxMjM0NTZhb3VpZScsJ2FvdWllMTIzNDU2Jyk7JF9SPWVyZWdfcmVwbGFjZSgnX19GSUxFX18nLCInIi4kX0YuIiciLCRfWCk7ZXZhbCgkX1IpOyRfUj0wOyRfWD0wOw=='));?>
										</optgroup>														
								</select> 
							</div>
						</div>								
						
						<div class="form-group">								
							<div class="input-group">									
								<div class="input-group-prepend">
									<span class="input-group-text"><i class="fas fa-user-circle" style="color:red;"></i></span>
								</div>
									<input type="text" class="form-control" id="username" placeholder="Username" name="user" autocomplete="off" >
							</div>
						</div>
						<div class="form-group">								
							<div class="input-group">
								<div class="input-group-prepend">
									<span class="input-group-text"><i class="fas fa-key" style="color:red;"></i></span>
								</div>
									<input type="text" class="form-control" id="password" placeholder="Password" name="password" autocomplete="off"  >
							</div>						
						</div>						
						<div class="form-group">									
							<div class="input-group">									
								<div class="input-group-prepend">
									<span class="input-group-text"><i class="fas fa-key" style="color:red;"></i></span>
								</div>
									<input type="text" class="form-control" id="confirm" placeholder="Confirm Password" name="confirmpassword" autocomplete="off" >
							</div>						
						</div>						
						<div class="form-group ">
							<button type="submit" id="button" class="btn btn-danger btn-block btn-action">CREATE ACCOUNT</button>
						</div>
					</form>					
				</div>
			</div>
		</div>
	</div>
</body>
</html>
