#!/bin/bash
#Script: XMR Mining - Logs
#Script Author : _Dreyannz_
clear
nano /tmp/xmrig.log