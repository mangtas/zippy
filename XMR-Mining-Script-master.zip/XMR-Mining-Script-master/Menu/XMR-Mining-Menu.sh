#!/bin/bash
#Script: XMR Mining - Menu
#Script Author : _Dreyannz_
clear
echo -e "                                                        "
echo -e "\e[94m    :::::::::  :::::::::   ::::::::  :::   :::    "
echo -e "\e[94m    :+:    :+: :+:    :+: :+:    :+: :+:   :+:    "
echo -e "\e[94m    +:+    +:+ +:+    +:+        +:+  +:+ +:+     "
echo -e "\e[94m    +#+    +:+ +#++:++#:      +#++:    +#++:      "
echo -e "\e[94m    +#+    +#+ +#+    +#+        +#+    +#+       "
echo -e "\e[94m    #+#    #+# #+#    #+# #+#    #+#    #+#       "
echo -e "\e[94m    #########  ###    ###  ########     ###       "
echo -e "\e[94m          XMR Miner Script by _Dreyannz_          "
echo -e "\e[94m                                                  "
echo -e "\e[94m             XMR Miner Control Center             "
echo -e "\e[94m                                                  "
echo -e "\e[94m       [menu/start/stop/status/config/logs]       "
echo -e "\e[94m                                                  "
echo -e "\e[94m             Track Your Progress At:              "
echo -e "\e[94m        https://supportxmr.com/#/dashboard        "
echo -e "\e[0m                                                  "