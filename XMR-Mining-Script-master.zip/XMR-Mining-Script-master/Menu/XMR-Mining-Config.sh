#!/bin/bash
#Script: XMR Mining - Config
#Script Author : _Dreyannz_
clear
nano /etc/config.json